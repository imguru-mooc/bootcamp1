#ifndef SENSOR_H
#define SENSOR_H

#define PCF8591_ADDR  0x48
#define ADC_MAX       255

/* PCF8591 아날로그 입력 채널 */
typedef enum {
    CH_LIGHT = 0,   /* AIN0 : 조도 */
    CH_TEMP  = 1,   /* AIN1 : 온도 */
    CH_POT   = 3    /* AIN3 : 가변저항 */
} AdcChannel;

/* 센서 1개를 표현하는 구조체 */
typedef struct {
    const char *name;
    AdcChannel  channel;
    int         raw;      /* 0 ~ 255 */
    float       scaled;   /* 변환된 물리값 */
} Sensor;

void  sensor_init(Sensor *s, const char *name, AdcChannel ch);
int   sensor_read_raw(Sensor *s);
float sensor_scale(const Sensor *s);
void  sensor_print(const Sensor *s);

#endif /* SENSOR_H */
