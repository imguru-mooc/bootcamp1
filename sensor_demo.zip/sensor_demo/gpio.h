#ifndef GPIO_H
#define GPIO_H

/* RGB LED 핀 (BCM 번호) */
#define LED_RED    17
#define LED_GREEN  27
#define LED_BLUE   22

/* 버튼 핀 */
#define BTN_A   5
#define BTN_B   6
#define BTN_C   13

/* 핀 모드 */
typedef enum {
    PIN_INPUT  = 0,
    PIN_OUTPUT = 1
} PinMode;

/* 핀 전압 레벨 */
typedef enum {
    LOW  = 0,
    HIGH = 1
} PinLevel;

void        gpio_setup(int pin, PinMode mode);
void        gpio_write(int pin, PinLevel level);
PinLevel    gpio_read(int pin);
const char *pin_name(int pin);

#endif /* GPIO_H */
