#include <stdio.h>
#include "sensor.h"

void sensor_init(Sensor *s, const char *name, AdcChannel ch) {
    s->name    = name;
    s->channel = ch;
    s->raw     = 0;
    s->scaled  = 0.0f;
}

int sensor_read_raw(Sensor *s) {
    /* 채널마다 다른 가상 ADC 값 생성 */
    s->raw = (s->channel * 70 + 45) % (ADC_MAX + 1);
    return s->raw;
}

float sensor_scale(const Sensor *s) {
    switch (s->channel) {
        case CH_TEMP:  return s->raw * 0.4f;                       /* 섭씨 근사 */
        case CH_LIGHT: return s->raw / (float)ADC_MAX * 100.0f;    /* 밝기 % */
        default:       return s->raw / (float)ADC_MAX * 3.3f;      /* 전압 V */
    }
}

void sensor_print(const Sensor *s) {
    printf("[%-10s] AIN%d  raw=%3d  scaled=%6.2f\n",
           s->name, s->channel, s->raw, s->scaled);
}
