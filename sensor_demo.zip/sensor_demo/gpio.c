#include <stdio.h>
#include "gpio.h"

static const char *g_mode_str[] = { "INPUT", "OUTPUT" };

void gpio_setup(int pin, PinMode mode) {
    printf("[GPIO] pin %2d 설정 → %s\n", pin, g_mode_str[mode]);
}

void gpio_write(int pin, PinLevel level) {
    printf("[GPIO] pin %2d 출력 → %s\n", pin, level == HIGH ? "HIGH" : "LOW");
}

PinLevel gpio_read(int pin) {
    /* 실제 하드웨어 대신 가상 값 반환 */
    return (pin % 2 == 0) ? HIGH : LOW;
}

const char *pin_name(int pin) {
    switch (pin) {
        case LED_RED:   return "RED LED";
        case LED_GREEN: return "GREEN LED";
        case LED_BLUE:  return "BLUE LED";
        case BTN_A:     return "Button A";
        case BTN_B:     return "Button B";
        case BTN_C:     return "Button C";
        default:        return "UNKNOWN";
    }
}
