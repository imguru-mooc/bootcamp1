#include <stdio.h>
#include "gpio.h"
#include "sensor.h"

static void blink_rgb(void) {
    int pins[3] = { LED_RED, LED_GREEN, LED_BLUE };
    for (int i = 0; i < 3; i++) {
        gpio_setup(pins[i], PIN_OUTPUT);
        gpio_write(pins[i], HIGH);
        printf("   → %s ON\n", pin_name(pins[i]));
    }
}

static void scan_sensors(void) {
    Sensor sensors[3];
    sensor_init(&sensors[0], "조도",     CH_LIGHT);
    sensor_init(&sensors[1], "온도",     CH_TEMP);
    sensor_init(&sensors[2], "가변저항", CH_POT);

    for (int i = 0; i < 3; i++) {
        sensor_read_raw(&sensors[i]);
        sensors[i].scaled = sensor_scale(&sensors[i]);
        sensor_print(&sensors[i]);
    }
}

int main(void) {
    printf("=== RGB LED 제어 ===\n");
    blink_rgb();

    printf("\n=== 센서 스캔 (PCF8591 @ 0x%02X) ===\n", PCF8591_ADDR);
    scan_sensors();

    return 0;
}
